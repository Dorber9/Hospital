package Utils;

public enum Specialization {
	
	
	UROLOGY,PSYCHIATRY,OPHTHALMOLOGY,GYNECOLOGY,NEUROLOGY,FAMILY,EMERGENCY 


}
