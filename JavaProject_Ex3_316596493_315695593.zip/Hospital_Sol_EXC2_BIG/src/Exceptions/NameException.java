package Exceptions;

public class NameException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public NameException() {
		super("Name must contain only letters.");	
	}
		
}

