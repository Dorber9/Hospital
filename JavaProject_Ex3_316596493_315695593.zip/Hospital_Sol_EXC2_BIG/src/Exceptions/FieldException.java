package Exceptions;

public class FieldException {

}
