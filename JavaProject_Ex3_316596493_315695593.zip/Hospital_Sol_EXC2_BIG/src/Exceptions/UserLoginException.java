package Exceptions;

public class UserLoginException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public UserLoginException(String s) {
		super(s);	
	}
		
}
